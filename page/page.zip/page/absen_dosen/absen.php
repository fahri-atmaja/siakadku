<?php
	if ($_access == 'mahasiswa' && $_id != $_username) {
		header("location:{$_url}krs/view/{$_username}");
	}
?>
<?php 
function hari_ini(){
	$hari = date ("D");
 
	switch($hari){
		case 'Sun':
			$hari_ini = "Minggu";
		break;
 
		case 'Mon':			
			$hari_ini = "Senin";
		break;
 
		case 'Tue':
			$hari_ini = "Selasa";
		break;
 
		case 'Wed':
			$hari_ini = "Rabu";
		break;
 
		case 'Thu':
			$hari_ini = "Kamis";
		break;
 
		case 'Fri':
			$hari_ini = "Jumat";
		break;
 
		case 'Sat':
			$hari_ini = "Sabtu";
		break;
		
		default:
			$hari_ini = "Tidak di ketahui";		
		break;
	}
 
	return "<b>" . $hari_ini . "</b>";
 
}
 
echo "Hari ini adalah " . hari_ini();
 
?>
<?php
			$tanggalskrg = date("d-m-y");
			$jamskrg = date('h:i');
		?>
<?php

$querya = mysqli_query($koneksi, 
			"select jk.*,ak.nama_konsentrasi,mm.nama_makul,ad.nama_lengkap,ah.hari_id,ah.hari,ar.ruangan_id,
			ar.nama_ruangan,ata.keterangan,ata.tahun_akademik_id
			FROM akademik_jadwal_kuliah as jk,app_hari as ah,akademik_konsentrasi as ak,makul_matakuliah as mm,app_dosen as ad,app_ruangan as ar,
			akademik_tahun_akademik as ata
			WHERE jk.konsentrasi_id=ak.konsentrasi_id and jk.hari_id=ah.hari_id
			and jk.makul_id=mm.makul_id and jk.dosen_id=ad.dosen_id and jk.ruangan_id=ar.ruangan_id and jk.tahun_akademik_id=ata.tahun_akademik_id  
			and jk.jadwal_id='$_id'");
$field = mysqli_fetch_array($querya);
extract($field);
?>
<h1>
<a href="<?= $_url ?><?= in_array($_access, array('admin','fakultas'))?'absen_dosen' : '' ?>" class="nav-button transform"><span></span></a>
Presensi Dosen Jadwal<br><?= $nama_makul ?>
</h1>


<?php
	
if (isset($_POST['submit'])) {
	$tanggalabsen       	= $_POST['tanggalabsen'];
	$jamabsen				= $_POST['jamabsen'];
	$materi					= $_POST['materi'];
	$hariskrg				= hari_ini();
	$harijadwal				= $_POST['hari'];
	$cekdulu = mysqli_num_rows(mysqli_query($koneksi,"SELECT * from dosen_absen where tanggalabsen ='$tanggalabsen' and jadwal_id='$_id'"));
	//$prosescek = mysqli_query($koneksi, $cekdulu);
	//if (mysqli_num_rows($prosescek)>0){
	//	echo "<script>window.alert('Anda Sudah Absen') window.location='{$_url}absen_dosen' </script>";
	if ($cekdulu > 0){
		echo "<script>window.alert('MAAF HARI INI DOSEN SUDAH ABSEN')
    window.location.href='{$_url}absen_dosen'</script>";
	}
	
	else {

	$sql = "UPDATE akademik_jadwal_kuliah SET pertemuan=pertemuan-1 WHERE jadwal_id='$_id'";
	$sql2= "INSERT into dosen_absen (absen_id,jadwal_id,tanggalabsen,jamabsen,materi) values ('','$_id','$tanggalabsen','$jamabsen','$materi')";
	$queque = mysqli_query($koneksi, $sql);
 	$queque2 = mysqli_query($koneksi, $sql2);
	if ($queque) {
		echo "<script>$.Notify({
		    caption: 'Success',
		    content: 'Data Jadwal Berhasil Diubah',
    		type: 'success'
		});
		setTimeout(function(){ window.location.href='{$_url}absen_dosen'; }, 2000);
		</script>";
	} else {
		echo "<script>$.Notify({
		    caption: 'Failed',
		    content: 'Data Jadwal Gagal Diubah',
		    type: 'alert'
		});</script>";
	}
	if ($queque2) {
		echo "<script>$.Notify({
		    caption: 'Success',
		    content: 'Data Absen Berhasil Ditambah',
    		type: 'success'
		});
		setTimeout(function(){ window.location.href='{$_url}absen_dosen'; }, 2000);
		</script>";
	} else {
		echo "<script>$.Notify({
		    caption: 'Failed',
		    content: 'Data Absen Gagal Ditambah',
		    type: 'alert'
		});</script>";
	}
}
}
?>
<?php 
	$hariskrg				= hari_ini(); ?>
<b>Pertemuan ke - <?= $field['pertemuan_mhs'] - $field['pertemuan'] ?> </b>
<?php
	$rule = $field['pertemuan_mhs'];
	$meet = $field['pertemuan_mhs'] - $field['pertemuan'];
	$cek = $rule - $meet;
 ?>
<form Method="POST">
		<input type="hidden" name="jadwal_id" id="jadwal_id" value="<?= $field['jadwal_id'] ?>" readonly>
	
	<table class="table striped hovered border bordered">
		<tr>
	<td>
		<div class="form-group">
		<div class="cell">
		<label>Jadwal Hari</label>
		<input type="text" name="hari" id="hari" value="<?= $field['hari'] ?>" readonly>
		</div>
</td>
<td>
		<div class="form-group">
		<div class="cell">
		<label>Mata Kuliah</label>
		<input type="text" name="nama_makul" id="nama_makul" value="<?= $field['nama_makul'] ?>" readonly>
		</div>
</td><td>
		<div class="cell">
		<label>Semester</label>
		<input type="text" name="semester" id="semester" value="<?= $field['semester'] ?>" readonly>
		</div>
</td><td>
		<div class="cell">
		<label>Konsentrasi</label>
		<input type="hidden" name="konsentrasi_id" id="konsentrasi_id" value="<?= $field['konsentrasi_id'] ?>">
		<input type="text" name="nama_konsentrasi" id="nama_konsentrasi" value="<?= $field['nama_konsentrasi'] ?>" readonly>
		</div>
		</div>
</td>
		</tr>
		<tr>
		<td>
		<div class="cell">
		<label>Dosen Pengampu</label>
				<input type="text" name="dosen_id" value="<?= $field['nama_lengkap'] ?>" readonly> 
		</div>
		</td>
			<input type="hidden" name="jamabsen" id="jamabsen" value="<?php echo $jamskrg ?>" readonly>
		
		<input type="hidden" name="tanggalabsen" id="tanggalabsen" value="<?php echo $tanggalskrg ?>">
		
		<td>
		<div class="cell">
		<label>Materi yang akan disampaikan </label>
		<input type="text" name="materi" id="materi" value="" required>
		</div>
		</td>
			
		</tr>
	<td>
		<?php if ($cek == "0"): ?>
		<p>Absen sudah selesai</p>
		<?php else: ?>
		<button type="submit" name="submit" class="button primary">SUBMIT</button>
		<?php endif; ?>
	</td>
	</table>
</form>
<?php
	$sql3	= "SELECT * FROM dosen_absen WHERE jadwal_id = '$_id'";
	$query3 = mysqli_query($koneksi, $sql3);
?>
<table class="table striped hovered border bordered">
	<thead>
		<tr>
			<th>No</th>
			<th>Tanggal Absen</th>
			<th>Jam Absen</th>
			<th>Materi</th>
		</tr>
	</thead>
	<tbody>

	<?php
		$noo=1;
		if (mysqli_num_rows($query3) > 0):
			while($field3 = mysqli_fetch_array($query3)):
	?>

		<tr>
			<td><?= $noo++ ?></td>
			<td><?= $field3['tanggalabsen'] ?></td>
			<td><?= $field3['jamabsen'] ?></td>
			<td><?= $field3['materi'] ?></td>
		</tr>
	<?php
			endwhile;
		else:
	?>
		<tr>
			<td colspan="4">
			Data tidak ditemukan
			</td>
		</tr>
	<?php
		endif;
	?>
		
	</tbody>
</table>