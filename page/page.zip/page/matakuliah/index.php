<?php
	if ($_access == 'mahasiswa' && $_id != $_username) {
		header("location:{$_url}krs/view/{$_username}");
	}
?>
<h1>
<a href="<?= $_url ?>" class="nav-button transform"><span></span></a>
Matakuliah
<span class="place-right">
	<a href="<?= $_url ?>matakuliah/import" class="button">Import Matakuliah</a>
</span>
</h1>

<?php
	$sql = "SELECT kode_makul, nama_makul, sks, semester, nama_konsentrasi FROM makul_matakuliah INNER JOIN akademik_konsentrasi ON akademik_konsentrasi.konsentrasi_id=makul_matakuliah.konsentrasi_id";
	$query = mysqli_query($koneksi, $sql);
?>

<table class="table striped hovered border bordered">
	<thead>
		<tr>
			<th>Kode</th>
			<th>Nama</th>
			<th>SKS</th>
			<th>Semester</th>
			<th>Program Studi</th>
			<th></th>
		</tr>
	</thead>
	<tbody>

	<?php
		if (mysqli_num_rows($query) > 0):
			while($field = mysqli_fetch_array($query)):
	?>
		<tr>
			<td><?= $field['kode_makul'] ?></td>
			<td><?= $field['nama_makul'] ?></td>
			<td><?= $field['sks'] ?></td>
			<td><?= $field['semester'] ?></td>
			<td><?= $field['nama_konsentrasi'] ?></td>
			<td>
				<div class="inline-block">
				    <button class="button mini-button dropdown-toggle">Aksi</button>
				    <ul class="split-content d-menu" data-role="dropdown">
						<li><a href="<?= $_url ?>matakuliah/view/<?= $field['kode'] ?>/<?= urlencode($field['nama']) ?>">
						<span class="mif-zoom-in"></span> View</a></li>
						<li><a href="<?= $_url ?>matakuliah/edit/<?= $field['kode'] ?>/<?= urlencode($field['nama']) ?>">
						<span class="mif-pencil"></span> Edit</a></li>
						<li><a href="<?= $_url ?>matakuliah/delete/<?= $field['kode'] ?>/<?= urlencode($field['nama']) ?>">
						<span class="mif-cross"></span> Delete</a></li>
				    </ul>
				</div>
			</td>
		</tr>
	<?php
			endwhile;
		else:
	?>
		<tr>
			<td colspan="6">
			Data tidak ditemukan
			</td>
		</tr>
	<?php
		endif;
	?>
		
	</tbody>
</table>