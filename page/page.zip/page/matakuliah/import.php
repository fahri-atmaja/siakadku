<a href="<?= $_url ?>matakuliah" class="nav-button transform"><span></span></a>
Matakuliah
<br/><br/>

<form method="post" enctype="multipart/form-data" action="aksi_upload">
	Pilih File: 
	<input name="matakuliah" type="file" required="required"> 
	<br>
	<input name="upload" type="submit" value="Import">
</form>
 
<br/><br/>
 
<a href="https://www.malasngoding.com/import-excel-ke-mysql-dengan-php">www.malasngoding.com</a>
 